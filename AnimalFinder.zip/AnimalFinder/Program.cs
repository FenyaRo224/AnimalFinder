﻿using System;
using System.Windows.Forms;
using AnimalFinder.Services;

namespace AnimalFinder
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Инициализация Supabase (как у тебя было)
            SupabaseService.InitializeAsync().GetAwaiter().GetResult();

            // Запуск главной формы
            Application.Run(new MainForm());
        }
    }
}